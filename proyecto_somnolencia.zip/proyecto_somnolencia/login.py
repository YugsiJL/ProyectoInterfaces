import tkinter as tk
from PIL import Image, ImageTk
from tkinter import messagebox
from pantallaCarga import show_loading_screen  # Importamos la pantalla de carga
from registro import *  # Importa la función desde registro.py


def LoginWindow():
    # Crear la ventana principal
    root = tk.Tk()
    root.title("Login")
    root.geometry("700x700")
    root.configure(bg="black")

    # Crear el primer label con la primera parte del texto
    texto_bienvenida_1 = tk.Label(root, text="Bienvenido al sistema de", 
                                  font=("Edwardian Script ITC", 32), fg="white", bg="black")
    texto_bienvenida_1.pack(pady=0)  # Añadir un espacio vertical

    # Crear el segundo label con la segunda parte del texto
    texto_bienvenida_2 = tk.Label(root, text="reconocimiento de somnolencia", 
                                  font=("Edwardian Script ITC", 32), fg="white", bg="black")
    texto_bienvenida_2.pack(pady=0)  # Añadir un espacio vertical

    # Crear el tercer label con la palabra "by"
    texto_bienvenida_3 = tk.Label(root, text="by", 
                                  font=("Edwardian Script ITC", 32), fg="white", bg="black")
    texto_bienvenida_3.pack(pady=0)  # Añadir un espacio vertical

    # Cargar la imagen del logo usando PIL
    imagen_original = Image.open("Logo.png")  # Sustituye con la ruta correcta
    imagen_redimensionada = imagen_original.resize((250, 200))  # Redimensiona la imagen a 250x200

    # Convertir la imagen redimensionada a un formato compatible con Tkinter
    logo = ImageTk.PhotoImage(imagen_redimensionada)

    # Crear un label para la imagen
    imagen_logo = tk.Label(root, image=logo, bg="black")
    imagen_logo.pack(pady=10)  # Ajustar el espacio alrededor de la imagen

    # Crear el texto debajo de la imagen
    texto_proceder = tk.Label(root, text="¿Cómo deseas proceder?", 
                              font=("Arial", 20), fg="white", bg="black")
    texto_proceder.pack(pady=10)

    # Crear el frame debajo de la imagen con tamaño específico
    frame_boton = tk.Frame(root, bg="black", width=475, height=150)  # Ajustar el tamaño aquí
    frame_boton.pack_propagate(False)  # Evitar que el frame cambie de tamaño por los hijos
    frame_boton.pack(pady=20)  # Añadir espacio vertical

    # Cargar las imágenes para los botones (reemplaza con las rutas correctas)
    imagen_sesion = Image.open("Iniciar.png")
    imagen_sesion_redimensionada = imagen_sesion.resize((65, 75))  # Aumentar tamaño de la imagen
    imagen_sesion_tk = ImageTk.PhotoImage(imagen_sesion_redimensionada)

    imagen_nuevo_usuario = Image.open("Nuevo.png")
    imagen_nuevo_usuario_redimensionada = imagen_nuevo_usuario.resize((75, 75))  # Aumentar tamaño de la imagen
    imagen_nuevo_usuario_tk = ImageTk.PhotoImage(imagen_nuevo_usuario_redimensionada)

    # Crear los botones en el frame con más tamaño y la imagen a la izquierda
    boton_iniciar_sesion = tk.Button(frame_boton, text="Iniciar sesión", font=("Arial", 10), 
                                     width=215, height=75, image=imagen_sesion_tk, compound="left", bg="black", fg="white", command=ingreso_usuario)   
    boton_iniciar_sesion.pack(side="left", padx=5)  # Usar pack con side="left" para los botones en horizontal

    boton_nuevo_usuario = tk.Button(frame_boton, text="Nuevo usuario", font=("Arial", 10), 
                                     width=215, height=75, image=imagen_nuevo_usuario_tk, compound="left" , bg="black", fg="white", command=nuevo_usuario)
    boton_nuevo_usuario.pack(side="left", padx=5)  # Usar pack con side="left" para los botones en horizontal

    root.mainloop()

def destruir_ventana(root):
    root.destroy()  # Cierra la ventana


if __name__ == "__main__":
    LoginWindow()
