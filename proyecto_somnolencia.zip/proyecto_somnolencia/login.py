import tkinter as tk
from tkinter import messagebox
from pantallaCarga import show_loading_screen  # Importamos la pantalla de carga

# Diccionario de usuarios (puedes reemplazarlo con una base de datos)
USUARIOS = {"admin": "1234", "usuario": "pass"}

def validar_login(usuario, contraseña, root):
    if usuario in USUARIOS and USUARIOS[usuario] == contraseña:
        root.destroy()  # Cierra la ventana de login
        show_loading_screen()  # Muestra la pantalla de carga y luego la interfaz principal
    else:
        messagebox.showerror("Error", "Usuario o contraseña incorrectos")

def LoginWindow():
    root = tk.Tk()
    root.title("Login")
    root.geometry("400x300")
    root.configure(bg="#1a1a2e")

    tk.Label(root, text="Usuario:", bg="#1a1a2e", fg="white", font=("Arial", 12)).pack(pady=5)
    entry_usuario = tk.Entry(root)
    entry_usuario.pack(pady=5)

    tk.Label(root, text="Contraseña:", bg="#1a1a2e", fg="white", font=("Arial", 12)).pack(pady=5)
    entry_contraseña = tk.Entry(root, show="*")
    entry_contraseña.pack(pady=5)

    btn_login = tk.Button(root, text="Ingresar", bg="#f9a826", fg="black", font=("Arial", 12, "bold"),
                          command=lambda: validar_login(entry_usuario.get(), entry_contraseña.get(), root))
    btn_login.pack(pady=20)

    root.mainloop()

if __name__ == "__main__":
    LoginWindow()
