# login.py
import tkinter as tk
from tkinter import messagebox

class LoginWindow:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Login - Monitoreo de Somnolencia")
        self.root.geometry("400x300")

        # Etiquetas y campos de entrada para usuario y contraseña
        tk.Label(self.root, text="Usuario:").pack(pady=10)
        self.user_entry = tk.Entry(self.root)
        self.user_entry.pack(pady=5)

        tk.Label(self.root, text="Contraseña:").pack(pady=10)
        self.password_entry = tk.Entry(self.root, show="*")
        self.password_entry.pack(pady=5)

        tk.Button(self.root, text="Ingresar", command=self.login).pack(pady=20)

    def login(self):
        user = self.user_entry.get()
        password = self.password_entry.get()

        # Validación básica (se puede sustituir por una validación real o consulta a la BD)
        if user == "admin" and password == "admin":
            self.root.destroy()  # Cierra la ventana de login si la validación es correcta
        else:
            messagebox.showerror("Error", "Usuario o contraseña incorrectos.")

    def run(self):
        self.root.mainloop()
