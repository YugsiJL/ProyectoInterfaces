# main.py
from login import LoginWindow
from main_interface import MainInterface

def main():
    # Inicia el login
    login_window = LoginWindow()
    login_window.run()  # Esto bloqueará hasta que se cierre la ventana de login

    # Una vez validado, se inicia la interfaz principal
    main_interface = MainInterface()
    main_interface.run()

if __name__ == '__main__':
    main()
