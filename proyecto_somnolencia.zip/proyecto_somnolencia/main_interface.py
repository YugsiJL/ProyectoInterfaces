# main_interface.py
import tkinter as tk
from tkinter import messagebox
import cv2
import mediapipe as mp
from PIL import Image, ImageTk

from activities import ActivitiesWindow
from sleep_test import SleepTestWindow
from results import ResultsWindow
from drowsiness_monitor import DrowsinessMonitor

class MainInterface:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Sistema de Monitoreo de Somnolencia")
        self.root.geometry("1000x600")

        # Dentro de la clase MainInterface, en el __init__():
        self.drowsiness_monitor = DrowsinessMonitor(ear_threshold=0.25)

        # Crear dos marcos: uno a la izquierda para los botones y otro a la derecha para la cámara.
        self.left_frame = tk.Frame(self.root, width=300)
        self.left_frame.grid(row=0, column=0, sticky="ns")  # Ocupa todo el alto

        self.right_frame = tk.Frame(self.root)
        self.right_frame.grid(row=0, column=1, sticky="nsew")  # Ocupa el resto de la ventana

        # Configurar el grid para que la columna de la derecha se expanda
        self.root.grid_columnconfigure(1, weight=1)
        self.root.grid_rowconfigure(0, weight=1)

        # --- Panel Izquierdo: Botones de interacción ---
        tk.Button(self.left_frame, text="Actividades", command=self.open_activities, width=20, height=2).pack(pady=10, padx=10)
        tk.Button(self.left_frame, text="Test de Somnolencia", command=self.open_sleep_test, width=20, height=2).pack(pady=10, padx=10)
        tk.Button(self.left_frame, text="Resultados", command=self.open_results, width=20, height=2).pack(pady=10, padx=10)
        tk.Button(self.left_frame, text="Salir", command=self.root.quit, width=20, height=2).pack(pady=10, padx=10)

        # --- Panel Derecho: Área de video y botón de control ---
        # Contenedor para el video que se ajusta al espacio disponible.
        # Se utiliza highlightthickness para el borde, que será rojo cuando la cámara esté apagada.
        self.video_container = tk.Frame(
            self.right_frame, 
            bg="black", 
            highlightthickness=5, 
            highlightbackground="red"
        )
        self.video_container.pack(expand=True, fill="both", padx=20, pady=20)

        # Etiqueta donde se mostrará el video en tiempo real, dentro del contenedor.
        self.video_label = tk.Label(self.video_container, bg="black")
        self.video_label.pack(expand=True, fill="both", padx=5, pady=5)

        # Marco para el botón de control de la cámara (ubicado en la parte inferior del panel derecho)
        self.control_frame = tk.Frame(self.right_frame)
        self.control_frame.pack(side="bottom", pady=10)

        # Botón para iniciar/apagar la cámara.
        self.cam_button = tk.Button(self.control_frame, text="Iniciar Cámara", command=self.toggle_camera, width=20, height=2)
        self.cam_button.pack()

        # Variables para la captura de video y procesamiento.
        self.cap = None
        self.running = False

        # Configuración de MediaPipe para detección de puntos faciales (por ejemplo, para detectar ojos).
        self.mp_face_mesh = mp.solutions.face_mesh.FaceMesh(refine_landmarks=True)
        self.mp_drawing = mp.solutions.drawing_utils

    def open_activities(self):
        ActivitiesWindow(self.root)

    def open_sleep_test(self):
        SleepTestWindow(self.root)

    def open_results(self):
        ResultsWindow(self.root)

    def toggle_camera(self):
        """
        Inicia o detiene la captura de video y actualiza el borde del contenedor.
        """
        if self.running:
            # Detener la captura.
            self.running = False
            self.cam_button.config(text="Iniciar Cámara")
            # Actualiza el borde a color rojo cuando la cámara esté apagada.
            self.video_container.config(highlightbackground="red")
        else:
            # Iniciar la captura de video.
            self.cap = cv2.VideoCapture(0)  # Índice 0 para la cámara predeterminada.
            if not self.cap.isOpened():
                messagebox.showerror("Error", "No se pudo abrir la cámara")
                return
            self.running = True
            self.cam_button.config(text="Apagar Cámara")
            # Actualiza el borde a color verde cuando la cámara esté encendida.
            self.video_container.config(highlightbackground="green")
            self.process_video()

    def process_video(self):
        """
        Captura y procesa el video en tiempo real. Se utiliza MediaPipe para el procesamiento facial.
        """
        if self.running:
            ret, frame = self.cap.read()
            if ret:
                # Convertir de BGR a RGB.
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

                # Procesamiento con MediaPipe.
                results = self.mp_face_mesh.process(frame_rgb)
                

                if results.multi_face_landmarks:
                # Para cada rostro detectado, se actualiza el monitoreo de somnolencia y se dibujan los landmarks
                    for face_landmarks in results.multi_face_landmarks:
                    # Actualiza el análisis de somnolencia: dibuja los 6 puntos de cada ojo, muestra EAR y PERCLOS.
                    # Se asume que este método dibuja sobre 'frame' (en BGR) o sobre 'frame_rgb'; se debe unificar.
                     frame, ear, perclos = self.drowsiness_monitor.update(
                        frame, 
                        face_landmarks, 
                        frame.shape[1], 
                        frame.shape[0]
                    )
                    
                    # Dibujar landmarks adicionales (por ejemplo, contornos) sobre la imagen convertida
                    self.mp_drawing.draw_landmarks(
                        frame_rgb,
                        face_landmarks,
                        mp.solutions.face_mesh.FACEMESH_CONTOURS,
                        landmark_drawing_spec=self.mp_drawing.DrawingSpec(color=(0, 255, 0), thickness=1, circle_radius=1),
                        connection_drawing_spec=self.mp_drawing.DrawingSpec(color=(0, 0, 255), thickness=1)
                    )
            

                # Si se prefiere que la información dibujada (por EAR/PERCLOS) se vea en el video mostrado,
            # se debe asegurar de que se dibuje sobre la misma imagen que se convierte a PIL.
            # Aquí, por ejemplo, se podría elegir 'frame' (en BGR) y luego convertirlo a RGB:
            frame_final = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            
            # Convertir la imagen para mostrarla en Tkinter.
            img = Image.fromarray(frame_final)
            imgtk = ImageTk.PhotoImage(image=img)
            self.video_label.imgtk = imgtk  # Mantener referencia para evitar recolección de basura.
            self.video_label.configure(image=imgtk)
              
            # Llamada recursiva cada 10 ms para actualizar el video.
            self.video_label.after(10, self.process_video)
        else:
            # Si se detiene la captura, liberar la cámara y limpiar la etiqueta de video.
            if self.cap:
                self.cap.release()
                self.video_label.config(image="")

    def run(self):
        self.root.mainloop()



if __name__ == '__main__':
    interface = MainInterface()
    interface.run()
