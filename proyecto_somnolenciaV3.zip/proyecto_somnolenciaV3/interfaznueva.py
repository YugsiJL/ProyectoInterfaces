import tkinter as tk
from tkinter import messagebox
import psycopg2
from psycopg2 import sql

def login():
    username = user_entry.get()
    password = pass_entry.get()
    if verificar_ingreso_usuario(username, password):
        messagebox.showinfo("Login exitoso", "Bienvenido")
    else:
        messagebox.showerror("Error", "Usuario o contraseña incorrectos")

def obtener_conexion():
    return psycopg2.connect(
        host="localhost",
        dbname="Interfaces",
        user="postgres",
        password="1234"
    )

def verificar_ingreso_usuario(ci, contrasena):
    try:
        conn = obtener_conexion()
        cursor = conn.cursor()
        query = sql.SQL("SELECT 1 FROM usuarios WHERE ci = %s AND contrasena = %s")
        cursor.execute(query, (ci, contrasena))
        existe = cursor.fetchone()
        cursor.close()
        conn.close()
        return bool(existe)
    except Exception as e:
        print(f"Error al verificar el ingreso del usuario: {e}")
        return False

root = tk.Tk()
root.title("Sistema de Autenticación")
root.geometry("700x350")
root.config(bg="#3E4A61")

# Panel izquierdo (Login)
frame_login = tk.Frame(root, bg="#6D8B8E", width=280, height=250, bd=5, relief="ridge")
frame_login.place(x=50, y=50)

tk.Label(frame_login, text="Usuario", bg="#6D8B8E", fg="white", font=("Arial", 12, "bold")).pack(pady=5)
user_entry = tk.Entry(frame_login, width=30, font=("Arial", 12))
user_entry.pack(pady=5)

tk.Label(frame_login, text="Contraseña", bg="#6D8B8E", fg="white", font=("Arial", 12, "bold")).pack(pady=5)
pass_entry = tk.Entry(frame_login, width=30, font=("Arial", 12), show="*")
pass_entry.pack(pady=5)

login_button = tk.Button(frame_login, text="Ingresar", bg="#E5AFAF", fg="black", font=("Arial", 12, "bold"), command=login)
login_button.pack(pady=10)

# Panel derecho (Información adicional)
frame_info = tk.Frame(root, bg="#3E4A61", width=350, height=250)
frame_info.place(x=370, y=50)

tk.Label(frame_info, text="Bienvenido", bg="#3E4A61", fg="white", font=("Arial", 16, "bold")).pack(pady=15)
tk.Label(frame_info, text="¿Olvidaste tu contraseña?", bg="#3E4A61", fg="white", font=("Arial", 12)).pack()
tk.Label(frame_info, text="¿No tienes cuenta? Regístrate aquí", bg="#3E4A61", fg="white", font=("Arial", 12)).pack()
tk.Label(frame_info, text="← Volver", bg="#3E4A61", fg="white", font=("Arial", 12, "underline")).pack(pady=10)

root.mainloop()
