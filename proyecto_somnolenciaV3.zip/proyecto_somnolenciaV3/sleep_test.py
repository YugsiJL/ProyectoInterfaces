# sleep_test.py
import tkinter as tk

class SleepTestWindow:
    def __init__(self, master):
        self.top = tk.Toplevel(master)
        self.top.title("Test de Somnolencia")
        self.top.geometry("400x300")

        tk.Label(self.top, text="Responde las siguientes preguntas:", font=("Arial", 14)).pack(pady=10)
        
        # Ejemplo de pregunta
        tk.Label(self.top, text="¿Te sientes somnoliento?").pack(pady=5)
        self.answer_var = tk.StringVar(value="No")
        tk.Radiobutton(self.top, text="Sí", variable=self.answer_var, value="Sí").pack()
        tk.Radiobutton(self.top, text="No", variable=self.answer_var, value="No").pack()

        tk.Button(self.top, text="Enviar", command=self.submit, width=20).pack(pady=20)

    def submit(self):
        answer = self.answer_var.get()
        # Aquí se puede procesar la respuesta y almacenarla o enviarla al módulo de resultados
        tk.Label(self.top, text=f"Respuesta enviada: {answer}").pack()
